总核数 = 128
任务名称 = dsp5u10
满载排至node8 = N
是否保留作业卡 = Y
执行命令:

cd $PBS_O_WORKDIR
NP=`cat $PBS_NODEFILE |wc -l`
cat $PBS_NODEFILE >aa

export PATH=/home/chenxuemin/zhangtao/soft/openmpi-4.1.1/bin:$PATH
export LD_LIBRARY_PATH=/home/chenxuemin/zhangtao/soft/miniconda3/envs/pr-dns/lib:/home/chenxuemin/zhangtao/soft/openmpi-4.1.1/lib:$LD_LIBRARY_PATH

mpirun -np $NP  -machinefile $PBS_NODEFILE --mca  btl_openib_allow_ib 1  ./climate -d 3 -p 8 4 4 -i input-pr-dns/in-entrainment3dd_case2 -o k5_u10_s1.002 |& tee /home/chenxuemin/zhangtao/PR_DNS_base/DNS/climate/$PBS_JOBID
