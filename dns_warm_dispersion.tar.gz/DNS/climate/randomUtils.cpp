#include "randomUtils.h"
#include <iostream>
#include <vector>
#include <cstdlib>
#include <random>
#include <algorithm>

using namespace std;
std::vector<double> generateGammaDistribution(int targetTotalCount, unsigned int seed)
{
std::default_random_engine generator(seed);
std::vector<double> rangeConcentration={10.0587242943,10.6803779230,10.8677228180,10.7818513307,10.5183682328,10.1391610685,\
    9.6863587867,9.1895149645,8.6697212515,8.1421500756,7.6177179284,7.1042210016,6.6071364844,6.1302025472,5.6758465473,5.2455060907,\
    4.8398726413,4.4590780396,4.1028382532,3.7705646671,3.4614504626,3.1745377137,2.9087694481,2.6630299213,2.4361756103,2.2270588785,\
    2.0345458439,1.8575296563,1.6949401442,1.5457505912,1.4089822530,1.2837071024,1.1690491922,1.0641849512,0.9683426645,0.8808013400,\
    0.8008891233,0.7279813893,0.6614986141,0.6009041087,0.5457016768,0.4954332497,0.4496765340,0.4080427030,0.3701741535,0.3357423442,\
    0.3044457256,0.2760077706,0.2501751085};
std::vector<double> dropletRadii={0.00000125,0.00000175,0.00000225,0.00000275,0.00000325,0.00000375,0.00000425,0.00000475,0.00000525,\
    0.00000575,0.00000625,0.00000675,0.00000725,0.00000775,0.00000825,0.00000875,0.00000925,0.00000975,0.00001025,0.00001075,0.00001125,\
    0.00001175,0.00001225,0.00001275,0.00001325,0.00001375,0.00001425,0.00001475,0.00001525,0.00001575,0.00001625,0.00001675,0.00001725,\
    0.00001775,0.00001825,0.00001875,0.00001925,0.00001975,0.00002025,0.00002075,0.00002125,0.00002175,0.00002225,0.00002275,0.00002325,\
    0.00002375,0.00002425,0.00002475,0.00002525};
std::vector<double> expectedCounts(rangeConcentration.size());
double totalExpectedCount=0.0;
for(size_t i=0;i<rangeConcentration.size();i++)
{
expectedCounts[i]=rangeConcentration[i]*targetTotalCount;
totalExpectedCount+=expectedCounts[i];
}
std::vector<double> randomCounts(rangeConcentration.size());
double totalRandomCount=0.0;
for(size_t i=0;i<rangeConcentration.size();i++)
{
std::gamma_distribution<double> gammaDist(expectedCounts[i],1.0);
randomCounts[i]=gammaDist(generator);
totalRandomCount+=randomCounts[i];
}
double adjustmentFactor=targetTotalCount/totalRandomCount;
for(size_t i=0;i<rangeConcentration.size();i++)
{
randomCounts[i]*=adjustmentFactor;
}
std::vector<int> roundedCounts(rangeConcentration.size());
for(size_t i=0;i<rangeConcentration.size();i++)
{
roundedCounts[i]=std::round(randomCounts[i]);
}
std::vector<double> radiiList;
for (size_t i=0;i<dropletRadii.size();i++)
{
 for (int j=0;j<roundedCounts[i];j++)
{
radiiList.push_back(dropletRadii[i]);
}
}
return radiiList;
}
