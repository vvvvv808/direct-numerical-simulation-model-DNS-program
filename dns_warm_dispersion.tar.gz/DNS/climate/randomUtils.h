#ifndef RANDOMUTILS_H
#define RANDOMUTILS_H

#include <vector>
using namespace std;
std::vector<double> generateGammaDistribution(int targetTotalCount, unsigned int seed);
#endif
