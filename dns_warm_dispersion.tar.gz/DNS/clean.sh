rm -rf climate/climate   CMakeCache.txt CMakeFiles climate/CMakeFiles  iFluid/CMakeFiles src/CMakeFiles solver/CMakeFiles
